/*TUSS - Tabela 51 - Terminologia de tipo de atendimento em odontologia*/
insert into TAB_51 (CodTermo,Termo,NumeroTabela) values ('1','Tratamento Odontol�gico','51');
insert into TAB_51 (CodTermo,Termo,NumeroTabela) values ('2','Exame Radiol�gico','51');
insert into TAB_51 (CodTermo,Termo,NumeroTabela) values ('3','Ortodontia','51');
insert into TAB_51 (CodTermo,Termo,NumeroTabela) values ('4','Urg�ncia/Emerg�ncia','51');
insert into TAB_51 (CodTermo,Termo,NumeroTabela) values ('5','Auditoria','51');
