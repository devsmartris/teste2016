/*Tabela 45 - Terminologia de status da solicita��o*/
insert into TAB_45 (CodTermo,Termo,NumeroTabela) values ('1','Autorizado','45');
insert into TAB_45 (CodTermo,Termo,NumeroTabela) values ('2','Em an�lise','45');
insert into TAB_45 (CodTermo,Termo,NumeroTabela) values ('3','Negado','45');
insert into TAB_45 (CodTermo,Termo,NumeroTabela) values ('4','Aguardando justificativa t�cnica do solicitante','45');
insert into TAB_45 (CodTermo,Termo,NumeroTabela) values ('5','Aguardando documenta��o do prestador','45');
insert into TAB_45 (CodTermo,Termo,NumeroTabela) values ('6','Solicita��o cancelada','45');
insert into TAB_45 (CodTermo,Termo,NumeroTabela) values ('7','Autorizado parcialmente','45');