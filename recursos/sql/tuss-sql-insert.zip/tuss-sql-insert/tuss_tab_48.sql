/*TUSS - Tabela 48 - Terminologia de t�cnica utilizada*/
insert into TAB_48 (CodTermo,Termo,NumeroTabela) values ('1','Convencional','48');
insert into TAB_48 (CodTermo,Termo,NumeroTabela) values ('2','Video','48');
insert into TAB_48 (CodTermo,Termo,NumeroTabela) values ('3','Rob�tica','48');
