/*TUSS - Tabela 25 - Terminologia de c�digo da despesa*/
insert into TAB_25 (CodTermo,Termo,NumeroTabela) values ('01','Gases medicinais','25');
insert into TAB_25 (CodTermo,Termo,NumeroTabela) values ('02','Medicamentos','25');
insert into TAB_25 (CodTermo,Termo,NumeroTabela) values ('03','Materiais','25');
insert into TAB_25 (CodTermo,Termo,NumeroTabela) values ('05','Di�rias','25');
insert into TAB_25 (CodTermo,Termo,NumeroTabela) values ('07','Taxas e alugu�is','25');
insert into TAB_25 (CodTermo,Termo,NumeroTabela) values ('08','OPME','25');