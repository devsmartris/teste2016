/*TUSS - Tabela 41 - Terminologia de Regime de Interna��o*/
insert into TAB_41 (CodTermo,Termo,NumeroTabela) values ('1','Hospitalar','41');
insert into TAB_41 (CodTermo,Termo,NumeroTabela) values ('2','Hospital�dia','41');
insert into TAB_41 (CodTermo,Termo,NumeroTabela) values ('3','Domiciliar','41');
