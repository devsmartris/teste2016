/*TUSS - Tabela 33 - Terminologia de finalidade do tratamento*/
insert into TAB_33 (CodTermo,Termo,NumeroTabela) values ('1','Curativa','33');
insert into TAB_33 (CodTermo,Termo,NumeroTabela) values ('2','Neoadjuvante','33');
insert into TAB_33 (CodTermo,Termo,NumeroTabela) values ('3','Adjuvante','33');
insert into TAB_33 (CodTermo,Termo,NumeroTabela) values ('4','Paliativa','33');
insert into TAB_33 (CodTermo,Termo,NumeroTabela) values ('5','Controle','33');