/*TUSS - Tabela 23 - Terminologia de car�ter do atendimento*/
insert into TAB_23 (CodTermo,Termo,NumeroTabela) values ('1','Eletivo','23');
insert into TAB_23 (CodTermo,Termo,NumeroTabela) values ('2','Urg�ncia/Emerg�ncia','23');