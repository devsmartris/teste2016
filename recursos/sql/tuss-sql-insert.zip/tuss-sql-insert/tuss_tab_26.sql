/*TUSS - Tabela 26 - Terminologia de conselho profissional*/
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('01','Conselho Regional de Assist�ncia Social (CRAS)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('02','Conselho Regional de Enfermagem (COREN)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('03','Conselho Regional de Farm�cia (CRF)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('04','Conselho Regional de Fonoaudiologia (CRFA)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('05','Conselho Regional de Fisioterapia e Terapia Ocupacional (CREFITO)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('06','Conselho Regional de Medicina (CRM)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('07','Conselho Regional de Nutri��o (CRN)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('08','Conselho Regional de Odontologia (CRO)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('09','Conselho Regional de Psicologia (CRP)','26');
insert into TAB_26 (CodTermo,Termo,NumeroTabela) values ('10','Outros Conselhos ','26');
