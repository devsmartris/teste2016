/*TUSS - Tabela 35 - Terminologia de grau de participa��o*/
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('00','Cirurgi�o','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('01','Primeiro Auxiliar','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('02','Segundo Auxiliar','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('03','Terceiro Auxiliar','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('04','Quarto Auxiliar','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('05','Instrumentador ','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('06','Anestesista','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('07','Auxiliar de Anestesista','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('08','Consultor','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('09','Perfusionista','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('10','Pediatra na sala de parto','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('11','Auxiliar SADT','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('12','Cl�nico','35');
insert into TAB_35 (CodTermo,Termo,NumeroTabela) values ('13','Intensivista','35');