/*TUSS - Tabela 52 - Terminologia de tipo de consulta*/
insert into TAB_52 (CodTermo,Termo,NumeroTabela) values ('1','Primeira Consulta','52');
insert into TAB_52 (CodTermo,Termo,NumeroTabela) values ('2','Retorno','52');
insert into TAB_52 (CodTermo,Termo,NumeroTabela) values ('3','Pr�-natal','52');
insert into TAB_52 (CodTermo,Termo,NumeroTabela) values ('4','Por encaminhamento','52');