/*TUSS - Tabela 46 - Terminologia do status do cancelamento*/
insert into TAB_46 (CodTermo,Termo,NumeroTabela) values ('1','Cancelado com sucesso','46');
insert into TAB_46 (CodTermo,Termo,NumeroTabela) values ('2','N�o cancelado','46');
insert into TAB_46 (CodTermo,Termo,NumeroTabela) values ('3','Guia inexistente','46');
insert into TAB_46 (CodTermo,Termo,NumeroTabela) values ('4','Em processamento','46');
