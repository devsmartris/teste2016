/*TUSS - Tabela 30 - Terminologia de escala de capacidade funcional (ECOG - Escala de Zubrod)*/
insert into TAB_30 (CodTermo,Termo,NumeroTabela) values ('0','Totalmente ativo capaz de exercer, sem restri��es, todas as atividades que exercia antes do diagn�stico.','30');
insert into TAB_30 (CodTermo,Termo,NumeroTabela) values ('1','N�o exerce atividade f�sica extenuante, por�m � capaz de realizar um trabalho leve em casa ou no escrit�rio.','30');
insert into TAB_30 (CodTermo,Termo,NumeroTabela) values ('2','Caminha e � capaz de exercer as atividades de autocuidado, mas � incapaz de realizar qualquer atividade de trabalho. Permanece fora do leito mais de 50% das horas de vig�lia.','30');
insert into TAB_30 (CodTermo,Termo,NumeroTabela) values ('3','Capacidade de autocuidado limitada. Permanece no leito ou cadeira mais de 50% das horas de vig�lia.','30');
insert into TAB_30 (CodTermo,Termo,NumeroTabela) values ('4','Completamente dependente. N�o � capaz de exercer qualquer atividade de autocuidado. Totalmente confinado � cama ou cadeira.','30');
