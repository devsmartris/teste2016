/*TUSS - Tabela 58 - Terminologia de tipo de quimioterapia*/
insert into TAB_58 (CodTermo,Termo,NumeroTabela) values ('1','1a linha','58');
insert into TAB_58 (CodTermo,Termo,NumeroTabela) values ('2','2a linha','58');
insert into TAB_58 (CodTermo,Termo,NumeroTabela) values ('3','3a linha','58');
insert into TAB_58 (CodTermo,Termo,NumeroTabela) values ('4','Outras linhas','58');