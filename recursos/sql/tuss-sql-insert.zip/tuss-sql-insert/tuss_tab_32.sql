/*TUSS - Tabela 32 - Terminologia de faces do dente*/
insert into TAB_32 (CodTermo,Termo,NumeroTabela) values ('O','Oclusal','32');
insert into TAB_32 (CodTermo,Termo,NumeroTabela) values ('L','Lingual','32');
insert into TAB_32 (CodTermo,Termo,NumeroTabela) values ('M','Mesial','32');
insert into TAB_32 (CodTermo,Termo,NumeroTabela) values ('V','Vestibular','32');
insert into TAB_32 (CodTermo,Termo,NumeroTabela) values ('D','Distal','32');
insert into TAB_32 (CodTermo,Termo,NumeroTabela) values ('I','Incisal','32');
insert into TAB_32 (CodTermo,Termo,NumeroTabela) values ('P','Palatina','32');