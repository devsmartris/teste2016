/*TUSS - Tabela 55 - Terminologia de tipo de faturamento*/
insert into TAB_55 (CodTermo,Termo,NumeroTabela) values ('1','Parcial','55');
insert into TAB_55 (CodTermo,Termo,NumeroTabela) values ('2','Final','55');
insert into TAB_55 (CodTermo,Termo,NumeroTabela) values ('3','Complementar','55');
insert into TAB_55 (CodTermo,Termo,NumeroTabela) values ('4','Total','55');
