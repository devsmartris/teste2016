/*TUSS - Tabela 31 - Terminologia de estadiamento do tumor*/
insert into TAB_31 (CodTermo,Termo,NumeroTabela) values ('1','I','31');
insert into TAB_31 (CodTermo,Termo,NumeroTabela) values ('2','II','31');
insert into TAB_31 (CodTermo,Termo,NumeroTabela) values ('3','III','31');
insert into TAB_31 (CodTermo,Termo,NumeroTabela) values ('4','IV','31');
insert into TAB_31 (CodTermo,Termo,NumeroTabela) values ('5','N�o se aplica','31');
