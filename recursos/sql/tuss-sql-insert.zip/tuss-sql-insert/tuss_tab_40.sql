/*TUSS - Tabela  40 - Terminologia de origem do evento de aten��o � sa�de*/
insert into TAB_40 (CodTermo,Termo,NumeroTabela) values ('1','Rede Contratada, referenciada ou credenciada','40');
insert into TAB_40 (CodTermo,Termo,NumeroTabela) values ('2','Rede Pr�pria - Cooperados','40');
insert into TAB_40 (CodTermo,Termo,NumeroTabela) values ('3','Rede Pr�pria - Demais prestadores','40');
insert into TAB_40 (CodTermo,Termo,NumeroTabela) values ('4','Reembolso ao benefici�rio','40');