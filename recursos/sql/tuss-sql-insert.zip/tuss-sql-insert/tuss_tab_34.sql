/*TUSS - Tabela 34 - Terminologia de forma de pagamento*/
insert into TAB_34 (CodTermo,Termo,NumeroTabela) values ('1','Dep�sito / Transfer�ncia Banc�ria','34');
insert into TAB_34 (CodTermo,Termo,NumeroTabela) values ('2','Carteira','34');
insert into TAB_34 (CodTermo,Termo,NumeroTabela) values ('3','Boleto Banc�rio / DDA','34');
insert into TAB_34 (CodTermo,Termo,NumeroTabela) values ('4','Dinheiro / Cheque','34');