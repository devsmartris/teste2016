/*TUSS - Tabela 37 - Terminologia de indicador de d�bito e cr�dito*/
insert into TAB_37 (CodTermo,Termo,NumeroTabela) values ('1','D�bito','37');
insert into TAB_37 (CodTermo,Termo,NumeroTabela) values ('2','Cr�dito','37');
