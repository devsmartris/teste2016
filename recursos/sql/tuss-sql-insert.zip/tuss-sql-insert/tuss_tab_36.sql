/*TUSS - Tabela 36 - Terminologia de Indicador de Acidente*/
insert into TAB_36 (CodTermo,Termo,NumeroTabela) values ('0','Trabalho','36');
insert into TAB_36 (CodTermo,Termo,NumeroTabela) values ('1','Tr�nsito','36');
insert into TAB_36 (CodTermo,Termo,NumeroTabela) values ('2','Outros','36');
insert into TAB_36 (CodTermo,Termo,NumeroTabela) values ('9','N�o Acidente','36');