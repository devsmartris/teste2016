/*TUSS - Tabela 56 - Terminologia de tipo de guia*/
insert into TAB_56 (CodTermo,Termo,NumeroTabela) values ('1','Solicita��o','56');
insert into TAB_56 (CodTermo,Termo,NumeroTabela) values ('2','Faturamento','56');