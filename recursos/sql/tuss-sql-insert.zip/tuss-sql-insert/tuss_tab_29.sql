/*TUSS - Tabela 29 - Terminologia de diagn�stico por imagem*/
insert into TAB_29 (CodTermo,Termo,NumeroTabela) values ('1','Tomografia','29');
insert into TAB_29 (CodTermo,Termo,NumeroTabela) values ('2','Resson�ncia Magn�tica','29');
insert into TAB_29 (CodTermo,Termo,NumeroTabela) values ('3','Raios-X','29');
insert into TAB_29 (CodTermo,Termo,NumeroTabela) values ('4','Outras','29');
insert into TAB_29 (CodTermo,Termo,NumeroTabela) values ('5','Ultrassonografia','29');
insert into TAB_29 (CodTermo,Termo,NumeroTabela) values ('6','PET','29');