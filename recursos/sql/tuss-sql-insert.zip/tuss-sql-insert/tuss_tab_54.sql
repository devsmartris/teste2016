/*TUSS - Tabela  54 - Terminologia de tipo de evento de aten��o � sa�de*/
insert into TAB_54 (CodTermo,Termo,NumeroTabela) values ('1','Consulta','54');
insert into TAB_54 (CodTermo,Termo,NumeroTabela) values ('2','SP/SADT','54');
insert into TAB_54 (CodTermo,Termo,NumeroTabela) values ('3','Interna��o','54');
insert into TAB_54 (CodTermo,Termo,NumeroTabela) values ('4','Tratamento Odontol�gico','54');
