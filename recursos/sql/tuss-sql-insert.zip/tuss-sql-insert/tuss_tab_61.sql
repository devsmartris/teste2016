/*TUSS - Tabela 61 - Terminologia de via de acesso*/
insert into TAB_61 (CodTermo,Termo,NumeroTabela) values ('1','�nica','61');
insert into TAB_61 (CodTermo,Termo,NumeroTabela) values ('2','Mesma via','61');
insert into TAB_61 (CodTermo,Termo,NumeroTabela) values ('3','Diferentes vias','61');