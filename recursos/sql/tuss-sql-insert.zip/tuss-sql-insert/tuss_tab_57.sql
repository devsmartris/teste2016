/*TUSS - Tabela 57 - Terminologia de tipo de interna��o.*/
insert into TAB_57 (CodTermo,Termo,NumeroTabela) values ('1','Cl�nica','57');
insert into TAB_57 (CodTermo,Termo,NumeroTabela) values ('2','Cir�rgica','57');
insert into TAB_57 (CodTermo,Termo,NumeroTabela) values ('3','Obst�trica','57');
insert into TAB_57 (CodTermo,Termo,NumeroTabela) values ('4','Pedi�trica','57');
insert into TAB_57 (CodTermo,Termo,NumeroTabela) values ('5','Psiqui�trica','57');