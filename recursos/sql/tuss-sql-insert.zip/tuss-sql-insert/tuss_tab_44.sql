/*TUSS - Tabela 44 - Terminologia de situa��o dent�ria inicial*/
insert into TAB_44 (CodTermo,Termo,NumeroTabela) values ('H','H�gido','44');
insert into TAB_44 (CodTermo,Termo,NumeroTabela) values ('E','Extra��o indicada','44');
insert into TAB_44 (CodTermo,Termo,NumeroTabela) values ('A','Ausente','44');
insert into TAB_44 (CodTermo,Termo,NumeroTabela) values ('C','Cariado','44');
insert into TAB_44 (CodTermo,Termo,NumeroTabela) values ('R','Restaurado','44');