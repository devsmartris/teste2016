/*TUSS - Tabela 47 - Terminologia de status da guia e do protocolo*/
insert into TAB_47 (CodTermo,Termo,NumeroTabela) values ('1','Recebido','47');
insert into TAB_47 (CodTermo,Termo,NumeroTabela) values ('2','Em an�lise','47');
insert into TAB_47 (CodTermo,Termo,NumeroTabela) values ('3','Liberado para pagamento','47');
insert into TAB_47 (CodTermo,Termo,NumeroTabela) values ('4','Encerrado sem pagamento','47');
insert into TAB_47 (CodTermo,Termo,NumeroTabela) values ('5','Analisado e aguardando libera��o para o pagamento','47');
insert into TAB_47 (CodTermo,Termo,NumeroTabela) values ('6','Pagamento efetuado','47');
insert into TAB_47 (CodTermo,Termo,NumeroTabela) values ('7','N�o localizado','47');
insert into TAB_47 (CodTermo,Termo,NumeroTabela) values ('8','Aguardando informa��o complementar','47');