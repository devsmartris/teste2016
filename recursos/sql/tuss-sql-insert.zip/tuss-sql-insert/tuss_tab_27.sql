/*TUSS - Tabela 27 - Terminologia de d�bitos e cr�ditos*/
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('01','Imposto de renda retido na fonte (IRRF)','27');
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('02','Imposto sobre servi�os (ISS)','27');
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('03','Instituto nacional de seguridade social (INSS)','27');
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('04','Programa de integra��o social (PIS)','27');
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('05','Contribui��o sobre o financiamento da seguridade social (COFINS)','27');
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('06','Contribui��o sobre o lucro liquido (CSLL)','27');
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('07','Descontos financeiros','27');
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('08','Ajuste de pagamento anterior','27');
insert into TAB_27 (CodTermo,Termo,NumeroTabela) values ('09','Determina��o judicial','27');