/*TUSS - Tabela 53 - Terminologia de tipo de demonstrativo*/
insert into TAB_53 (CodTermo,Termo,NumeroTabela) values ('1','Demonstrativo de pagamento','53');
insert into TAB_53 (CodTermo,Termo,NumeroTabela) values ('2','Demonstrativo de an�lise de conta','53');
insert into TAB_53 (CodTermo,Termo,NumeroTabela) values ('3','Demonstrativo de pagamento odontol�gico','53');