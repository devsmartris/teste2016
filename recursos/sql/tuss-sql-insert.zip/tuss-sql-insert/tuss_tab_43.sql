/*TUSS - Tabela 43 - Sexo*/
insert into TAB_43 (CodTermo,Termo,NumeroTabela) values ('1','Masculino','43');
insert into TAB_43 (CodTermo,Termo,NumeroTabela) values ('3','Feminino','43');